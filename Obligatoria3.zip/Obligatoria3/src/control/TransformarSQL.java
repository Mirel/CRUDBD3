package control;

public class TransformarSQL {

	public static String pasarLibroSQL(Libros miLibro) {

		// INSERT INTO libros(titulo,autor,tipologia) VALUES ('"+ +"','"+ +"','"+ +"');

		return "INSERT INTO libros(titulo,autor,tipologia) VALUES ('" + miLibro.getTitulo() + "','" + miLibro.getAutor()
				+ "','" + miLibro.getTipologia() + "');";

	}

	public static String mostrarSQL() {

		return "Select * from libros;";

	}

	public static String pasartituloSQL(String titulo) {

		return "Select * from libros where titulo=('" + titulo + "');";

	}

	public static String pasarAutorSQL(String autor) {

		return "Select * from libros where autor=('" + autor + "');";

	}

	public static String pasartipoSQL(String tipo) {

		return "Select * from libros where tipologia=('" + tipo + "');";

	}

	public static String eliminarSQL(String titulo) {

		return "Delete from libros where titulo=('" + titulo + "');";

	}

	public static String modificarSQL(String titulo, Libros libro) {
		// update libros set titulo='titulo', autor='autor', tipologia = 'tipologia'
		// where titulo =''
		return "Update libros set titulo = '" + libro.getTitulo() + "', autor='" + libro.getAutor() + "', tipologia='"
				+ libro.getTipologia() + "' where titulo = ('" + titulo + "');";

	}
}
//....