package usuario;

public class MenuPrincipal {

	public static void mostrar() {
		System.out.println("    MENU: ");
		System.out.println("    1. Mostrar colección de libros ");
		System.out.println("    2. Añadir libro ");
		System.out.println("    3. Modificar libro ");
		System.out.println("    4. Eliminar libro ");
		System.out.println("    5. Buscar por titulo ");
		System.out.println("    6. Buscar por autor ");
		System.out.println("    7. Buscar por tipologia ");
		System.out.println("    8. Salir ");

	}

}
