import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class gestionBD {

	/*
	 * Realizaremos la mismas funcionalidades que en la primera práctica. Resumen:
	 * Debe aparecer un menú que pida al usuario la acción a realizar (añadir,
	 * modificar, borrar el contenido de la posición del array, buscar por
	 * cualquiera de los datos guardados y finalmente salir). El programa repetirá
	 * el menú hasta que se decida terminar. En este caso modificaremos la práctica
	 * para que: Los datos se almacenarán en una base de datos MySQL o SQLServer. Se
	 * penaliza -2 puntos por cada funcionalidad no implementada.
	 */

	/*
	 * public static void main(String[] args) { // TODO Auto-generated method stub
	 * 
	 * 
	 * try { Class.forName("com.mysql.jdbc.Driver"); Connection conexion =
	 * DriverManager.getConnection("jdbc:mysql://localhost:8889/biblioteca", "root",
	 * "root");
	 * 
	 * conexion.close();
	 * 
	 * System.out.println("Conectado/desconectado");
	 * 
	 * } catch (SQLException ex) { ex.printStackTrace();
	 * System.out.println("Error");
	 * 
	 * } catch (ClassNotFoundException e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); System.out.println("Error"); }
	 * 
	 * 
	 * }
	 */

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection conexion = null;
		Statement sentenciaSQL = null;
		ResultSet rs = null;
		int numero = 0;

		try {
			// conectar con la base de datos
			Class.forName("com.mysql.jdbc.Driver");
			conexion = DriverManager.getConnection("jdbc:mysql://localhost:8889/biblioteca", "root", "root");// proporcionamos
	// creamos sentencias ejecutables sobre esa conexión
			sentenciaSQL = conexion.createStatement();

			// almaceno el resultado de la sql en un resulset (conjunto de registros)
			rs = sentenciaSQL.executeQuery("SELECT * FROM libros");
			// chequeo que el result set no sea vacío, moviendo el cursor a la
			// primer fila. (El cursor inicia antes de la primer fila)
			if (rs.next()) {
				// Si hay resultados obtengo el valor.
				numero = rs.getInt(1);
				System.out.println(numero);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
			// System.out.println("Error");
		} finally {
			try {
				conexion.close();

			} catch (SQLException e) {
				// TODO: handle exception
				e.printStackTrace();
			}

		}

		System.out.println("Conectado/desconectado");

	}

}
